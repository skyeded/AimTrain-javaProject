package RunCodePackage;
import MainPackage.GameFrame;

public class AimTrainMain extends GameFrame{
		
	public static void main(String[] args) {
		
		new GameFrame();
		
		
		System.out.print(GameFrame.running);
	}

}
