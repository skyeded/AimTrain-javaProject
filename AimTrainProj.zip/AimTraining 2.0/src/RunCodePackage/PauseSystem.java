package RunCodePackage;

public interface PauseSystem {
	abstract void pause();
	abstract void resume();
}
