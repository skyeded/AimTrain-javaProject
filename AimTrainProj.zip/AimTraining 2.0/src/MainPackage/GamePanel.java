package MainPackage;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Ellipse2D.Double;
import java.awt.geom.Line2D;
import java.util.Random;
import javax.swing.JPanel;



public class GamePanel extends JPanel implements MouseListener, MouseMotionListener {
	

	final int s_WIDTH = 800;
	final int s_HEIGHT = 650;
	static int unitSize = 80;
	Random r;
	static double clickNo;
	static double hitNo;

	//Elipse2D are used for creating graphics object i.e ball1 to be use directly with MouseListener
	Ellipse2D ball1;
	Ellipse2D ball2;
	Ellipse2D ball3;
	
	static int minX = 100;
	static int maxX = 600;
	static int minY = 100;
	static int maxY = 600;
	
	private int mouseXH;
	private int mouseYH;
	private int mouseX2H;
	private int mouseY2H;
	private int mouseXV;
	private int mouseYV;
	private int mouseX2V;
	private int mouseY2V;
	
	private int ballX,ballY,ballX2,ballY2,ballX3,ballY3;
	
	public GamePanel(){
		
		r = new Random();
		this.setBackground(Color.BLACK);
		this.setPreferredSize(new Dimension(s_WIDTH, s_HEIGHT));
		
		addMouseListener(this);
		addMouseMotionListener(this);
		NewBalls();
		NewBalls2();
		NewBalls3();
	}
	
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		//Graphics2D used for drawing 2D graphics to draw Ellipse2D and Line2D
		Graphics2D g2 = (Graphics2D)g;
		if(GameFrame.running&GameFrame.pauseCheck==false&GameFrame.gameOverCheck==false) {
		
			//To create 3 balls at random location of X and Y at size depending on difficulties
			ball1 = new Ellipse2D.Double(ballX,ballY,unitSize,unitSize);
			ball2 = new Ellipse2D.Double(ballX2,ballY2,unitSize,unitSize);
			ball3 = new Ellipse2D.Double(ballX3,ballY3,unitSize,unitSize);
			g2.setColor(Color.YELLOW);
			g2.fill(ball1);
			g2.draw(ball1);
			g2.fill(ball2);
			g2.draw(ball2);
			g2.fill(ball3);
			g2.draw(ball3);
			
			//For drawing the cross-hair for the cursor
			g2.setColor(Color.magenta);
			g2.draw(new Line2D.Double(mouseXH,mouseYH,mouseX2H,mouseY2H));
			g2.draw(new Line2D.Double(mouseXV,mouseYV,mouseX2V,mouseY2V));
		
		}
		else if(GameFrame.running==false&GameFrame.easy==true&GameFrame.gameOverCheck==false) {
			GameFrame.EasySelected(g);
		}
		else if(GameFrame.running==false&GameFrame.medium==true&GameFrame.gameOverCheck==false) {
			GameFrame.MediumSelected(g);
		}
		else if(GameFrame.running==false&GameFrame.hard==true&GameFrame.gameOverCheck==false) {
			GameFrame.HardSelected(g);
		}
		else if(GameFrame.running==false&GameFrame.extra==true&GameFrame.gameOverCheck==false) {
			GameFrame.ExtraSelected(g);
		}
		else if(GameFrame.running&GameFrame.pauseCheck==true&GameFrame.gameOverCheck==false) {
			GameFrame.pauseText(g);
		}
		else if(GameFrame.gameOverCheck == true){
			if(GameFrame.blink) {
				GameFrame.gameOver(g);
			}
			else {
				GameFrame.hideOver(g);
			}
		}
		else {
			if(GameFrame.blink) {
				GameFrame.gameStart(g);
			}
			else {
				GameFrame.hideStart(g);
				
			}
		}
		
		//for displaying the graphics method multiple 'fastText' at 40 seconds and at random location on the game screen
		if(GameFrame.running&ScoreTimePanel.second==40) {
			GameFrame.fastText(g);
		}
		
		//for displaying the graphics method multiple 'fastText' at 20 seconds and at random location on the game screen
		else if(GameFrame.running&ScoreTimePanel.second==20) {
			GameFrame.goText(g);
		}
		
		//for displaying the graphics method multiple 'fastText' at 10 seconds and at random location on the game screen
		else if(GameFrame.running&ScoreTimePanel.second==10) {
			GameFrame.fastText(g);
		}
		
		//for displaying the graphics animation of the graphics method bgAnimate, movingAnimate and movingAnimate2
		if(GameFrame.running&GameFrame.animation) {
			GameFrame.bgAnimate(g);
			GameFrame.movingAnimate(g);
			GameFrame.movingAnimate2(g);
		}
		repaint();
	}
	
	//code for generating random location of balls on the screen
	public void NewBalls() {
		ballX = r.nextInt(maxX - minX + 1) + minX;
		ballY = r.nextInt(maxY - minY + 1) + minY;
	}
	public void NewBalls2() {
		ballX2 = r.nextInt(maxX - minX + 1) + minX;
		ballY2 = r.nextInt(maxY - minY + 1) + minY;
	}
	public void NewBalls3() {
		ballX3 = r.nextInt(maxX - minX + 1) + minX;
		ballY3 = r.nextInt(maxY - minY + 1) + minY;

	}

	public void mouseClicked(MouseEvent e) {
		
		
		
	}
	
	@Override
	//for registering to change the balls location when the ball has been pressed on
	//add score for clicking on the ball and subtract for missing
	public void mousePressed(MouseEvent e) {
		int inScore = 392;
		int outScore = 123;
		if (GameFrame.running) {
			if(GameFrame.extra==false) {
				if (ball1.contains(e.getPoint())) {
					ScoreTimePanel.score += inScore;
					ScoreTimePanel.scoreText.setText("Score: "+ScoreTimePanel.score);
					hitNo+=1;
					NewBalls();
					repaint();
				}
				else if (ball2.contains(e.getPoint())) {
					ScoreTimePanel.score += inScore;
					ScoreTimePanel.scoreText.setText("Score: "+ScoreTimePanel.score);
					hitNo+=1;
					NewBalls2();
					repaint();
				}
				else if (ball3.contains(e.getPoint())) {
					ScoreTimePanel.score += inScore;
					ScoreTimePanel.scoreText.setText("Score: "+ScoreTimePanel.score);
					hitNo+=1;
					NewBalls3();
					repaint();
				}
				else {
					ScoreTimePanel.score -= outScore;
					if (ScoreTimePanel.score<0) {
						ScoreTimePanel.score = 0;
					}
					ScoreTimePanel.scoreText.setText("Score: "+ScoreTimePanel.score);
				}
				clickNo+=1;
			}
			else {
				if (ball1.contains(e.getPoint())) {
					ScoreTimePanel.score += inScore;
					ScoreTimePanel.scoreText.setText("Score: "+ScoreTimePanel.score);
					hitNo+=1;
					NewBalls();
					NewBalls2();
					NewBalls3();
					repaint();
				}
				else if (ball2.contains(e.getPoint())) {
					ScoreTimePanel.score += inScore;
					ScoreTimePanel.scoreText.setText("Score: "+ScoreTimePanel.score);
					hitNo+=1;
					NewBalls();
					NewBalls2();
					NewBalls3();
					repaint();
				}
				else if (ball3.contains(e.getPoint())) {
					ScoreTimePanel.score += inScore;
					ScoreTimePanel.scoreText.setText("Score: "+ScoreTimePanel.score);
					hitNo+=1;
					NewBalls();
					NewBalls2();
					NewBalls3();
					repaint();
				}
				else {
					ScoreTimePanel.score -= outScore;
					if (ScoreTimePanel.score<0) {
						ScoreTimePanel.score = 0;
					}
					ScoreTimePanel.scoreText.setText("Score: "+ScoreTimePanel.score);
				}
				//number of clicks and number of pressing the balls are registered each time for calculating accuracy
				clickNo+=1;
		 }
		}
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	//use for registering cross-hair of the cursor
	public void mouseMoved(MouseEvent e) {
		if(GameFrame.running) {
			mouseXH = e.getX()-25;
			mouseYH = e.getY();
			mouseX2H = e.getX()+25;
			mouseY2H = e.getY();
			mouseXV = e.getX();
			mouseYV = e.getY()+25;
			mouseX2V = e.getX();
			mouseY2V = e.getY()-25;
		}
		repaint();
	
	}
	public void mouseDragged(MouseEvent e) {
		
	}
}



