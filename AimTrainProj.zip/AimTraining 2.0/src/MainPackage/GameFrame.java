package MainPackage;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.text.DecimalFormat;
import java.util.Random;

import javax.swing.*;

import RunCodePackage.PauseSystem;

public class GameFrame extends JFrame implements ActionListener,PauseSystem {
	
	//protected variables might be used when creating extra codes
	protected static boolean running = false;
	static boolean gameOn = false;
	static boolean gameOverCheck = false;
	static boolean easy = false;
	static boolean medium = false;
	static boolean hard = false;
	static boolean extra = false;
	static boolean pauseCheck = false;
	static boolean blink = true;
	
	static int i = 0;
	static int height = 800;
	static int width = 800;
	static Random ran;
	private static int animateX;
	private static int animateY;
	private static int moveAnimateX;
	private static int moveAnimateY;
	private static int moveAnimateX2;
	private static int moveAnimateY2;
	public static boolean animation=true;
	
	//Timer for background animation of game screen
	static Timer backgroundTimer;
	Timer blinkTimer;
	
	
	public GameFrame(){
			
		this.setLayout(new BorderLayout());
		this.add(new ScoreTimePanel(),BorderLayout.SOUTH);
		this.add(new GamePanel(),BorderLayout.CENTER);
		this.setTitle("Turbo Aim: Train your aim!");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
		this.setSize(width,height);
		this.setVisible(true);
		this.setLocationRelativeTo(null);
		this.addKeyListener(new MyKeyAdapter());
		ran = new Random();
		backgroundTimer = new Timer(1, this);
		blinkTimer = new Timer(800,this);
		blinkTimer.start();
		
	}
	public void startGame() {
		
		//for this code to run once (if) statement is used to limit running the for code more than once
		if(i<1) {
			running = true;
			ScoreTimePanel.CountDownTimer();
			ScoreTimePanel.timer.start();
			backgroundTimer.start();
		}
	}
	
	//Method used for stopping the code
	public static void stopGame() {
		running = false;
		
		//Boolean used for displaying GameOver screen
		gameOverCheck = true;
		backgroundTimer.stop();

	}

	//Graphics method for displaying the Start game screen
	public static void gameStart(Graphics g){
		Graphics2D g2 = (Graphics2D) g;
		FontMetrics metrics = g.getFontMetrics(new Font("Arial",Font.BOLD,32));
		int stringX = (width - metrics.stringWidth("Press SpaceBar to start!")) / 2;
		int stringY = ((height - metrics.getHeight()) /2) + metrics.getAscent();
		g.setFont(new Font("Arial",Font.BOLD,32));
		g.setColor(Color.RED);
		
		//Instruction text/string on how to start playing the game
		g.drawString("Press SpaceBar to start!", stringX, stringY);
		
		FontMetrics metricsSelect = g.getFontMetrics(new Font("Arial",Font.PLAIN,16));
		int stringXselect = (width - metricsSelect.stringWidth("Select difficulty: 1. Easy 2. Medium 3. Hard 4.Extra")) / 2;
		int stringYselect = (int) (((height - metricsSelect.getHeight())/1.8) + metricsSelect.getAscent());
		g.setFont(new Font("Arial",Font.PLAIN,16));
		g.setColor(Color.YELLOW);
		
		//Instruction for selection of the difficulties of the game
		g.drawString("Select difficulty: 1. Easy 2. Medium 3. Hard 4.Extra", stringXselect, stringYselect);
		//If the user doesn't select the difficulty it's automatically set to EASY 
	}
	
	public static void hideStart(Graphics g){
		Graphics2D g2 = (Graphics2D) g;
		FontMetrics metrics = g.getFontMetrics(new Font("Arial",Font.BOLD,32));
		int stringX = (width - metrics.stringWidth("Press SpaceBar to start!")) / 2;
		int stringY = ((height - metrics.getHeight()) /2) + metrics.getAscent();
		g.setFont(new Font("Arial",Font.BOLD,32));
		g.setColor(Color.BLACK);
		
		//Instruction text/string on how to start playing the game
		g.drawString("Press SpaceBar to start!", stringX, stringY);
		
		FontMetrics metricsSelect = g.getFontMetrics(new Font("Arial",Font.PLAIN,16));
		int stringXselect = (width - metricsSelect.stringWidth("Select difficulty: 1. Easy 2. Medium 3. Hard 4.Extra")) / 2;
		int stringYselect = (int) (((height - metricsSelect.getHeight())/1.8) + metricsSelect.getAscent());
		g.setFont(new Font("Arial",Font.PLAIN,16));
		g.setColor(Color.YELLOW);
		
		//Instruction for selection of the difficulties of the game
		g.drawString("Select difficulty: 1. Easy 2. Medium 3. Hard 4.Extra", stringXselect, stringYselect);
		//If the user doesn't select the difficulty it's automatically set to EASY 
	}
	
	//Graphics method for displaying the Start game screen when 'Easy' mode is selected
	public static void EasySelected(Graphics g) {
		FontMetrics metricsSelect = g.getFontMetrics(new Font("Arial",Font.BOLD,16));
		int stringXselect = (width - metricsSelect.stringWidth("You have selected EASY difficulty")) / 2;
		int stringYselect = (((height - metricsSelect.getHeight())/2) + metricsSelect.getAscent());
		g.setFont(new Font("Arial",Font.BOLD,16));
		g.setColor(Color.YELLOW);
		g.drawString("You have selected EASY difficulty", stringXselect, stringYselect);
		
		FontMetrics metrics = g.getFontMetrics(new Font("Arial",Font.BOLD,32));
		int stringX = (width - metrics.stringWidth("Press SpaceBar to start!")) / 2;
		int stringY = (int) (((height - metrics.getHeight()) /1.8) + metrics.getAscent());
		g.setFont(new Font("Arial",Font.BOLD,32));
		g.setColor(Color.RED);
		g.drawString("Press SpaceBar to start!", stringX, stringY);
	}
	
	//Graphics method for displaying the Start game screen when 'Medium' mode is selected
	public static void MediumSelected(Graphics g) {
		FontMetrics metricsSelect = g.getFontMetrics(new Font("Arial",Font.BOLD,16));
		int stringXselect = (width - metricsSelect.stringWidth("You have selected MEDIUM difficulty")) / 2;
		int stringYselect = (((height - metricsSelect.getHeight())/2) + metricsSelect.getAscent());
		g.setFont(new Font("Arial",Font.BOLD,16));
		g.setColor(Color.YELLOW);
		g.drawString("You have selected MEDIUM difficulty", stringXselect, stringYselect);
		
		FontMetrics metrics = g.getFontMetrics(new Font("Arial",Font.BOLD,32));
		int stringX = (width - metrics.stringWidth("Press SpaceBar to start!")) / 2;
		int stringY = (int) (((height - metrics.getHeight()) /1.8) + metrics.getAscent());
		g.setFont(new Font("Arial",Font.BOLD,32));
		g.setColor(Color.RED);
		g.drawString("Press SpaceBar to start!", stringX, stringY);
	}
	
	//Graphics method for displaying the Start game screen when 'Hard' mode is selected
	public static void HardSelected(Graphics g) {
		FontMetrics metricsSelect = g.getFontMetrics(new Font("Arial",Font.BOLD,16));
		int stringXselect = (width - metricsSelect.stringWidth("You have selected HARD difficulty")) / 2;
		int stringYselect = (((height - metricsSelect.getHeight())/2) + metricsSelect.getAscent());
		g.setFont(new Font("Arial",Font.BOLD,16));
		g.setColor(Color.YELLOW);
		g.drawString("You have selected HARD difficulty", stringXselect, stringYselect);
		
		FontMetrics metrics = g.getFontMetrics(new Font("Arial",Font.BOLD,32));
		int stringX = (width - metrics.stringWidth("Press SpaceBar to start!")) / 2;
		int stringY = (int) (((height - metrics.getHeight()) /1.8) + metrics.getAscent());
		g.setFont(new Font("Arial",Font.BOLD,32));
		g.setColor(Color.RED);
		g.drawString("Press SpaceBar to start!", stringX, stringY);
	
	}
	
	//Graphics method for displaying the Start game screen when 'Extra' mode is selected
	public static void ExtraSelected(Graphics g) {
		FontMetrics metricsSelect = g.getFontMetrics(new Font("Arial",Font.BOLD,16));
		int stringXselect = (width - metricsSelect.stringWidth("You have selected EXTRA difficulty")) / 2;
		int stringYselect = (((height - metricsSelect.getHeight())/2) + metricsSelect.getAscent());
		g.setFont(new Font("Arial",Font.BOLD,16));
		g.setColor(Color.YELLOW);
		g.drawString("You have selected EXTRA difficulty", stringXselect, stringYselect);
		
		FontMetrics metrics = g.getFontMetrics(new Font("Arial",Font.BOLD,32));
		int stringX = (width - metrics.stringWidth("Press SpaceBar to start!")) / 2;
		int stringY = (int) (((height - metrics.getHeight()) /1.8) + metrics.getAscent());
		g.setFont(new Font("Arial",Font.BOLD,32));
		g.setColor(Color.RED);
		g.drawString("Press SpaceBar to start!", stringX, stringY);
	}
	
	//Graphics method for displaying the Pause screen when 'Pause' button(p) is pressed
	public static void pauseText(Graphics g) {
		FontMetrics metrics = g.getFontMetrics(new Font("Arial",Font.BOLD,32));
		int stringX = (width - metrics.stringWidth("PAUSED")) / 2;
		int stringY = ((height - metrics.getHeight()) / 2) + metrics.getAscent();
		g.setFont(new Font("Arial",Font.BOLD,32));
		g.setColor(Color.RED);
		g.drawString("PAUSED", stringX, stringY);
		
	}
	
	//Graphics method for displaying the 'Game Over' + 'Your accuracy' screen
	public static void gameOver(Graphics g) {
		FontMetrics metrics = g.getFontMetrics(new Font("Arial",Font.BOLD,32));
		int stringX = (width - metrics.stringWidth("Game Over")) / 2;
		int stringY = ((height - metrics.getHeight()) / 2) + metrics.getAscent();
		g.setFont(new Font("Arial",Font.BOLD,32));
		g.setColor(Color.RED);
		g.drawString("Game Over", stringX, stringY);
		
		double accuracy = ((GamePanel.hitNo/GamePanel.clickNo)*100);
		int accuracyD;
		accuracyD = (int) accuracy;
		FontMetrics metricsAccuracy = g.getFontMetrics(new Font("Arial",Font.BOLD,20));
		int stringXaccuracy = (width - metrics.stringWidth("Your Accuracy: "+accuracyD+"%"))/2;
		int stringYaccuracy = (int) (((height - metrics.getHeight()) / 1.8) + metrics.getAscent());
		g.setFont(new Font("Arial",Font.BOLD,20));
		g.setColor(Color.BLUE);
		g.drawString("Your Accuracy: "+accuracyD+"%", stringXaccuracy+61, stringYaccuracy);
	}
	public static void hideOver(Graphics g) {
		FontMetrics metrics = g.getFontMetrics(new Font("Arial",Font.BOLD,32));
		int stringX = (width - metrics.stringWidth("Game Over")) / 2;
		int stringY = ((height - metrics.getHeight()) / 2) + metrics.getAscent();
		g.setFont(new Font("Arial",Font.BOLD,32));
		g.setColor(Color.BLACK);
		g.drawString("Game Over", stringX, stringY);
		
		double accuracy = ((GamePanel.hitNo/GamePanel.clickNo)*100);
		int accuracyD;
		accuracyD = (int) accuracy;
		FontMetrics metricsAccuracy = g.getFontMetrics(new Font("Arial",Font.BOLD,20));
		int stringXaccuracy = (width - metrics.stringWidth("Your Accuracy: "+accuracyD+"%"))/2;
		int stringYaccuracy = (int) (((height - metrics.getHeight()) / 1.8) + metrics.getAscent());
		g.setFont(new Font("Arial",Font.BOLD,20));
		g.setColor(Color.BLUE);
		g.drawString("Your Accuracy: "+accuracyD+"%", stringXaccuracy+61, stringYaccuracy);
	}
	
	//Graphics method for randomly displaying string/text 'FASTER! FASTER!' on the game screen
	public static void fastText(Graphics g) {
		g.setFont(new Font("Arial",Font.PLAIN,22));
		g.setColor(Color.GRAY);
		g.drawString("FASTER! FASTER!", ran.nextInt(GamePanel.maxX - GamePanel.minX + 1) 
				+ GamePanel.minX, ran.nextInt(GamePanel.maxY - GamePanel.minY + 1) + GamePanel.minY);
	}
	
	//Graphics method for randomly displaying string/text 'GO! GO! GO!!' on the game screen
	public static void goText(Graphics g) {
		g.setFont(new Font("Arial",Font.PLAIN,22));
		g.setColor(Color.GRAY);
		g.drawString("GO! GO! GO!", ran.nextInt(GamePanel.maxX - GamePanel.minX + 1) 
				+ GamePanel.minX, ran.nextInt(GamePanel.maxY - GamePanel.minY + 1) + GamePanel.minY);
	}
	
	//Graphics method for randomly displaying multiple 'Square' at random location X and Y on game screen 
	//Optional animation as long as the game is running
	public static void bgAnimate(Graphics g) {
		for(int i=0;i<10;i++) {
			animateX = ran.nextInt(800);
			animateY = ran.nextInt(800);
			g.setColor(Color.lightGray);
			g.drawRect(animateX,animateY,2, 2);
		}
	}
	
	//Graphics method for randomly displaying multiple 'Square' at random location of Y as X increases or move towards the right periodically
	//Optional animation as long as the game is running
	public static void movingAnimate(Graphics g) {
		for(int i=0;i<30;i++) {
			moveAnimateY = ran.nextInt(800);
			g.setColor(Color.lightGray);
			g.drawRect(moveAnimateX,moveAnimateY,2, 2);
			}
		}
	
	//Graphics method for randomly displaying multiple 'Square' at random location of X as Y increases or move downward periodically
	//Optional animation as long as the game is running
	public static void movingAnimate2(Graphics g) {
		for(int i=0;i<30;i++) {
			moveAnimateX2 = ran.nextInt(800);
			g.setColor(Color.lightGray);
			g.drawRect(moveAnimateX2,moveAnimateY2,2, 2);
			}
		}
	
	//Method for pausing
	public void pause() {
		pauseCheck = true;
		gameOn = true;
		ScoreTimePanel.timer.stop();
	
	}
	
	//Method for resuming the game if the game is paused
	public void resume() {
		pauseCheck = false;
		gameOn = false;
		ScoreTimePanel.timer.start();
	}
	
	//Method for converting the difficulty to be Easy 
	public void convertEasy() {
		hard = false;
		medium = false;
		extra = false;
		easy = true;
		GamePanel.unitSize = 80;
	}
	
	//Method for converting the difficulty to be Medium
	//Size of the ball is half of size of the ball from easy mode
	public void convertMedium() {
		easy = false;
		hard = false;
		extra = false;
		medium = true;
		GamePanel.unitSize = 40;
	}
	
	//Method for converting the difficulty to be Hard
	//Size of the ball is half of size of the ball from Medium mode
	public void convertHard() {
		easy = false;
		medium = false;
		extra = false;
		hard = true;
		GamePanel.unitSize = 20;
	}
	
	//Size of the ball is half of size of the ball from Extra mode
	//Size of the ball is same as Medium but position of the ball is randomized every time a ball is clicked
	public void convertExtra() {
		easy = false;
		medium = false;
		hard = false;
		extra = true;
		GamePanel.unitSize = 40;
		
	}
	
	@Override
	//Receive the action from the Timer 'backgroundTimer'
	public void actionPerformed(ActionEvent e) {
		
		//Move the location of method movingAnimate towards the left periodically 
		moveAnimateX+=1;
		
		//Move the location of method movingAnimate downwards periodically 
		moveAnimateY2+=1;
		
		//Reset the animation(to the right border of game screen) once movingAnimate reached the left border of the Game screen
		if(moveAnimateX==800) {
			moveAnimateX=0;
		}
		
		//Reset the animation(to the top  border of game screen) once movingAnimate reached the bottom border of the Game screen
		if(moveAnimateY2==650) {
			moveAnimateY2=0;
		}
		if(running==false) {
			if(blink==true) {
				blink=false;
			}
			else {
				blink=true;
			}
		}
	}
	
	//Received the action of keys on key board pressed
	public class MyKeyAdapter extends KeyAdapter{
		public void keyPressed(KeyEvent e) {
			switch(e.getKeyCode()) {
			
			//Allow to start the game when space bar is pressed
			case KeyEvent.VK_SPACE:
				startGame();
				
				//i is used for limiting the game to start for no more than one time
				i++;
				repaint();
				break;
				
			//Allow the selection of difficulty Easy when key '1' is pressed
			case KeyEvent.VK_1:
				if(running==false) {
					convertEasy();
					repaint();
				}
				break;
				
			//Allow the selection of difficulty Medium when key '2' is pressed
			case KeyEvent.VK_2:
				if(running == false) {
				convertMedium();
				repaint();
				}
				break;
				
			//Allow the selection of difficulty Hard when key '3' is pressed
			case KeyEvent.VK_3:
				if (running == false) {
				convertHard();
				repaint();
				}
				break;
				
			//Allow the selection of difficulty Extra when key '4' is pressed
			case KeyEvent.VK_4:
				if (running == false) {
				convertExtra();
				repaint();

				}
				break;
				
			//Allow the game to be paused when key 'p' is pressed
			case KeyEvent.VK_P:   
				if(gameOn) {
					resume();
					repaint();
				} else {
					pause();
					repaint();
			
				}
				break;
				
			//Allow the switching of on/off of animation on the game screen
			case KeyEvent.VK_A:
				if(animation) {
					animation = false;
				
				}
				else {
					animation = true;
				}
		
			}
		}
	}

	
}
