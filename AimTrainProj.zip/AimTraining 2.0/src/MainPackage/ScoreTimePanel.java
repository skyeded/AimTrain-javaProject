package MainPackage;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.text.DecimalFormat;

import javax.swing.*;


public class ScoreTimePanel extends JPanel {
	
	public static JLabel scoreText;
	static JLabel timeText;
	JLabel instruction;
	JLabel instruction2;

	static Timer timer;
	
	public static int score;
	 static int second;
	
	
	ScoreTimePanel(){
		this.setBackground(Color.BLACK);
		this.setLayout(new GridLayout(0,4));
		this.setPreferredSize(new Dimension(50,50));
		
		//set text for score 
		scoreText = new JLabel("Score: 0");
		scoreText.setForeground(Color.YELLOW);
		scoreText.setFont((new Font("Arial", Font.BOLD,16)));
		scoreText.setHorizontalAlignment(JLabel.CENTER);
		
		//set text for time 
		timeText = new JLabel("Time left: 60");
		timeText.setForeground(Color.YELLOW);
		timeText.setFont(new Font("Arial", Font.BOLD,16));
		timeText.setHorizontalAlignment(JLabel.CENTER);
		
		//set text for pause instruction
		instruction = new JLabel("Press P to PAUSE");
		instruction.setForeground(Color.RED);
		instruction.setFont(new Font("Arial", Font.BOLD,12));
		instruction.setHorizontalAlignment(JLabel.CENTER);
		
		//set text for animation instruction
		instruction2 = new JLabel("Press for A ON/OFF Animation");
		instruction2.setForeground(Color.BLUE);
		instruction2.setFont(new Font("Arial", Font.BOLD,12));
		instruction2.setHorizontalAlignment(JLabel.CENTER);
	
		this.add(timeText);
		this.add(instruction);
		this.add(instruction2);
		this.add(scoreText);
			
	}
	
	//count-down timer for the game
	public static void CountDownTimer() {
			timer = new Timer(1000, new ActionListener() {
			
				public void actionPerformed(ActionEvent e) {
					
					second--;
					timeText.setText("Time left: "+second);
				
					if(second == -1) {
						second = 59;
						timeText.setText("Time left: "+second);
					}
					
					//call function stopGame() from GameFrame when the timer is up or second == 0
					if(second == 0) {
						timer.stop();
						GameFrame.stopGame();
						
						
					}
					
					
				
					
				}
				
			});
			
		}
		
	
}

